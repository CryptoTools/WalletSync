

  WalletSync v. 0.0.0.2, created by zelles

  Keep a Sync/Backup of your crypto-currency wallets locally.
  Optionally you can have them sync to an FTP server.

  This program will sync any wallet.dat files found in their
  default location, AppData/Roaming/*/wallet.dat... The program
  will make a copy of all the wallets in the SyncData folder
  found in the script directory where WalletSync is run.

  The sync speed can be edit in the gui. If syncing FTP then you
  probably should not run it once a minute! If you want a faster 
  local sync you can edit the config.ini created by WalletSync in
  the directory it is run in. Where speed=X, the X would be the 
  amount of seconds between scans. Make sure to close WalletSync
  before changing the config.ini so that when WalletSync is opened,
  it can read the changes made to the config.ini.

  The WalletSync window can be minimized to the system tray to
  constantly stay syncing, a backup, in the background.

  Donate: 1LiENpyZYRVHtu7ep51S1AeecrA3hHEWYz

  CopyMe 2014 zelles